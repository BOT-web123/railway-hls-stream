# Railway HLS Stream

Este proyecto usa FFmpeg y NGINX para hacer un stream en HLS (HTTP Live Streaming) y desplegarlo fácilmente en Railway.